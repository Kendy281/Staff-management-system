<html>
  <head>
   <link rel="stylesheet" href="style.css">
    <title>IIR-GATE PASS</title>
  </head>
  <body>
  <!--  <?php echo '<p>Hello World</p>'; ?> -->

    <main>
    <div class="maincontent">
      <div class="side1main">
        <div class="side1">
          
          <a href="index.php"><img class="logoimg" src="CSIRlogo.jpg" alt="logo" srcset=""></a>
          
            
        </div>
      </div>
      <div class="side2">
        <div class="side2content">
          <h3>INSTITUTE VEHICLE FLEET MANAGEMENT SYSTEM</h3>
          <h5>Kindly choose a suitable option to proceed</h5>

          <!--
          <button class="createacc"> EMPLOYEE</button><br><br>

          <button class="createacc">HEAD OF DEPARTMENT</button>

          <button class="createacc">TRANSPORT DIRECTOR</button>

          <button class="createacc">HUMAN RESOURCES MANAGER</button>  -->



          <style>
            .button {
              display: inline-block;
              padding: 10px 20px;
              font-size: 16px;
              cursor: pointer;
              text-align: center;
              text-decoration: none;
              outline: none;
              color: #fff;
              background-color: #180F90;
              border: none;
              border-radius: 15px;
              box-shadow: 0 9px #999;
            }

            .button:hover {
              background-color: #3e8e41
            }

            .button:active {
              background-color: #3e8e41;
              box-shadow: 0 5px #666;
              transform: translateY(4px);
            }
          </style>

          <a href="employeelogin.php" <button class="button"> EMPLOYEE </button> </a>
          <br>
          <br>
          <br>
          <a href="HODlogin.html" <button class="button"> HEAD OF DIVISION </button> </a>
          <br>
          <br>
          <br>
          <a href="transportofficerlogin.html" <button class="button"> TRANSPORT OFFICER</button> </a>
          <br>
          <br>
          <br>
          <a href="HRlogin.html" <button class="button"> HUMAN RESOURCE MANAGER</button> </a> <br>



        </div>
      </div>
    </div>
  </main>
    

    <!--
    This script places a badge on your repl's full-browser view back to your repl's cover
    page. Try various colors for the theme: dark, light, red, orange, yellow, lime, green,
    teal, blue, blurple, magenta, pink!
    -->
   <!-- <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> -->
  </body>
</html>